﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Ionic.Zip;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace ZipDownloader.Layouts.ZipDownloader
{
    public partial class ZipDownloader : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var sourceListId = Request.Params["sourceId"];
            if (string.IsNullOrEmpty(sourceListId)) return;

            var listId = new Guid(Request.Params["sourceId"]);
            var list = Web.Lists[listId];
            var pItemIds = Request.Params["itemIDs"];
            if (string.IsNullOrEmpty(pItemIds)) return;
                
            var sItemIds = pItemIds.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            var itemsIDs = new int[sItemIds.Length];
            for (var i = 0; i < sItemIds.Length; i++)
            {
                itemsIDs[i] = Convert.ToInt32(sItemIds[i]);
            }
     
            if (itemsIDs.Length > 0)
            {
                var zip = new ZipFile();
                foreach (var file in itemsIDs.Select(id => list.GetItemById(id).File))
                {
                    zip.AddEntry(file.Name, file.OpenBinaryStream());
                }
                
                Response.Buffer = false;
                Response.ClearHeaders();
                Response.ClearContent();
                Response.ContentType = "application/zip";
                Response.AppendHeader("Content-Disposition", "attachment;filename=Reader.zip");

                zip.Save(Response.OutputStream);
                Response.Flush();

            }
        }
    }
}
